import Post from './components/Post';

function App() {
  return (
    <main>
      <Post author="Jordan Walke" body="ReactJs is awesome!"/>
      <Post author="Manuel" body="Check out the full course"/>
    </main>
  );
}

export default App;
